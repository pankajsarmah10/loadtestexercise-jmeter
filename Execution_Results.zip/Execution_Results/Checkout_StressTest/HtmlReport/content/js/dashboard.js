/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8220422189494354, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9925925925925926, 500, 1500, "GoToCartCheck"], "isController": false}, {"data": [0.9408284023668639, 500, 1500, "AddToCart"], "isController": false}, {"data": [0.9925, 500, 1500, "SelectProductView"], "isController": false}, {"data": [0.9903381642512077, 500, 1500, "SelectProductCheck"], "isController": false}, {"data": [0.8068181818181818, 500, 1500, "PlaceOrderDeletecart"], "isController": false}, {"data": [0.9919614147909968, 500, 1500, "LoginCheck"], "isController": false}, {"data": [0.9621212121212122, 500, 1500, "GoToCartViewcart"], "isController": false}, {"data": [0.9886363636363636, 500, 1500, "GoToCartView"], "isController": false}, {"data": [0.5, 500, 1500, "LaunchEntries"], "isController": false}, {"data": [0.9778012684989429, 500, 1500, "Login"], "isController": false}, {"data": [0.7522711390635919, 500, 1500, "Launch"], "isController": false}, {"data": [0.9961832061068703, 500, 1500, "PlaceOrderCheck"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4074, 0, 0.0, 454.6298478154146, 306, 1533, 409.0, 610.0, 615.0, 723.0, 2.1830094988241004, 4.957162302489617, 0.961779822708175], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GoToCartCheck", 135, 0, 0.0, 398.9111111111111, 328, 912, 408.0, 418.4, 441.79999999999995, 827.0399999999968, 0.07435210402685488, 0.044564469642311304, 0.033908625566934796], "isController": false}, {"data": ["AddToCart", 169, 0, 0.0, 429.61538461538464, 363, 767, 409.0, 507.0, 511.5, 731.3000000000006, 0.09306972023462382, 0.02754778961479599, 0.049079735279977395], "isController": false}, {"data": ["SelectProductView", 200, 0, 0.0, 390.8700000000001, 330, 536, 407.0, 411.0, 434.95, 517.97, 0.10982813544225319, 0.0816701964399759, 0.048049809255985766], "isController": false}, {"data": ["SelectProductCheck", 207, 0, 0.0, 394.57971014492716, 331, 514, 407.0, 446.80000000000007, 463.2, 510.91999999999996, 0.11367286925148887, 0.0686719957688432, 0.05184104486371611], "isController": false}, {"data": ["PlaceOrderDeletecart", 132, 0, 0.0, 458.27272727272725, 371, 561, 471.5, 511.0, 512.0, 545.4899999999994, 0.07269543092694936, 0.022151540372123503, 0.032727142243480126], "isController": false}, {"data": ["LoginCheck", 311, 0, 0.0, 394.66881028938906, 327, 662, 407.0, 426.0, 445.0, 512.64, 0.17078340710151454, 0.10302219017363895, 0.07788657335586649], "isController": false}, {"data": ["GoToCartViewcart", 132, 0, 0.0, 415.24242424242425, 355, 1065, 408.0, 479.7, 511.0, 887.7899999999933, 0.07270131655475069, 0.04448469895458811, 0.03429173427338339], "isController": false}, {"data": ["GoToCartView", 132, 0, 0.0, 396.66666666666674, 333, 551, 408.0, 432.0, 444.0, 549.02, 0.07269867391009818, 0.053611291997252876, 0.03159268543944696], "isController": false}, {"data": ["LaunchEntries", 621, 0, 0.0, 609.1739130434784, 528, 1381, 597.0, 666.8000000000001, 712.9, 1008.0199999999998, 0.34095176603132143, 0.5232356904232084, 0.1291887550978054], "isController": false}, {"data": ["Login", 473, 0, 0.0, 413.9260042283295, 347, 1441, 406.0, 460.6, 489.4999999999998, 579.559999999999, 0.25974168606949877, 0.14408243795441067, 0.12175391534507754], "isController": false}, {"data": ["Launch", 1431, 0, 0.0, 453.92382948986733, 306, 1533, 400.0, 612.0, 615.0, 706.4400000000005, 0.7667861052570663, 3.829563749577357, 0.3347201064940514], "isController": false}, {"data": ["PlaceOrderCheck", 131, 0, 0.0, 395.3969465648855, 329, 588, 408.0, 413.6, 432.9999999999999, 551.8400000000008, 0.07214864162282673, 0.04313460840223254, 0.03290372620884774], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4074, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
