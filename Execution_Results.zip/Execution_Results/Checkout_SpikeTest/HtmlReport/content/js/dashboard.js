/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8736469608659451, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9836065573770492, 500, 1500, "GoToCartCheck"], "isController": false}, {"data": [0.8709677419354839, 500, 1500, "AddToCart"], "isController": false}, {"data": [0.9838709677419355, 500, 1500, "SelectProductView"], "isController": false}, {"data": [0.9838709677419355, 500, 1500, "SelectProductCheck"], "isController": false}, {"data": [0.825, 500, 1500, "PlaceOrderDeletecart"], "isController": false}, {"data": [0.9779411764705882, 500, 1500, "LoginCheck"], "isController": false}, {"data": [0.9344262295081968, 500, 1500, "GoToCartViewcart"], "isController": false}, {"data": [1.0, 500, 1500, "GoToCartView"], "isController": false}, {"data": [0.5, 500, 1500, "LaunchEntries"], "isController": false}, {"data": [0.897196261682243, 500, 1500, "Login"], "isController": false}, {"data": [0.8759328358208955, 500, 1500, "Launch"], "isController": false}, {"data": [0.9915254237288136, 500, 1500, "PlaceOrderCheck"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2402, 0, 0.0, 413.68526228143196, 303, 1321, 358.5, 604.0, 631.8499999999999, 749.699999999998, 2.390071154866064, 8.565337315520736, 1.0525961022287762], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GoToCartCheck", 61, 0, 0.0, 400.7213114754099, 338, 511, 408.0, 440.40000000000003, 456.4, 511.0, 0.08012957346108526, 0.047438390538405054, 0.03654346758430353], "isController": false}, {"data": ["AddToCart", 62, 0, 0.0, 444.0322580645161, 373, 663, 415.0, 510.7, 517.9499999999999, 663.0, 0.08143782419149972, 0.024107586754269248, 0.04294572760098619], "isController": false}, {"data": ["SelectProductView", 62, 0, 0.0, 394.82258064516134, 336, 512, 406.0, 430.20000000000005, 454.54999999999995, 512.0, 0.08144328000987829, 0.05963801171338271, 0.03563143500432175], "isController": false}, {"data": ["SelectProductCheck", 62, 0, 0.0, 405.7741935483871, 335, 561, 408.0, 456.7, 473.65, 561.0, 0.08145183962921021, 0.04907663214050179, 0.037146493268399576], "isController": false}, {"data": ["PlaceOrderDeletecart", 60, 0, 0.0, 460.93333333333334, 391, 612, 459.5, 513.9, 545.6999999999999, 612.0, 0.07880624303057289, 0.024011277173377674, 0.035478201208099705], "isController": false}, {"data": ["LoginCheck", 68, 0, 0.0, 398.9558823529411, 328, 556, 407.0, 440.30000000000007, 500.54999999999995, 556.0, 0.08933134176989034, 0.05358700232261489, 0.04073997715482304], "isController": false}, {"data": ["GoToCartViewcart", 61, 0, 0.0, 421.8852459016394, 363, 556, 408.0, 506.0, 514.5, 556.0, 0.08014178526993987, 0.0484168569212942, 0.037801252231817344], "isController": false}, {"data": ["GoToCartView", 61, 0, 0.0, 392.54098360655735, 335, 466, 407.0, 430.0, 448.09999999999997, 466.0, 0.08013504725997254, 0.058597726989089806, 0.03482431252996854], "isController": false}, {"data": ["LaunchEntries", 131, 0, 0.0, 645.2519083969468, 538, 1321, 627.0, 711.8, 772.3999999999999, 1197.8000000000027, 0.17201081961185954, 0.26552016039024134, 0.06517597461855616], "isController": false}, {"data": ["Login", 107, 0, 0.0, 434.5794392523365, 363, 606, 408.0, 508.0, 524.8, 606.0, 0.14056180055725528, 0.07746370475913356, 0.06588834401121342], "isController": false}, {"data": ["Launch", 1608, 0, 0.0, 393.8544776119401, 303, 1190, 327.0, 597.0, 616.55, 711.9100000000001, 1.6000143284865236, 7.994425991750175, 0.6984437547201915], "isController": false}, {"data": ["PlaceOrderCheck", 59, 0, 0.0, 394.0677966101695, 330, 529, 405.0, 425.0, 460.0, 529.0, 0.07749351812691599, 0.04573985130438665, 0.035341282192646255], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2402, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
